package com.axelhabeillon.jeepcockpit.data.repository

import com.axelhabeillon.jeepcockpit.core.model.ConnectionState
import com.axelhabeillon.jeepcockpit.core.model.UserSettings
import com.axelhabeillon.jeepcockpit.core.model.VehicleIndicator
import com.axelhabeillon.jeepcockpit.core.model.VehicleTelemetry
import com.axelhabeillon.jeepcockpit.core.repository.SettingsRepository
import com.axelhabeillon.jeepcockpit.core.repository.VehicleRepository
import com.axelhabeillon.jeepcockpit.data.obd.Elm327BluetoothClient
import com.axelhabeillon.jeepcockpit.data.obd.Elm327Parser
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class VehicleRepositoryImpl @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val elm327: Elm327BluetoothClient,
) : VehicleRepository {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var pollingJob: Job? = null
    private val _telemetry = MutableStateFlow(VehicleTelemetry())
    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)

    override val telemetry: StateFlow<VehicleTelemetry> = _telemetry.asStateFlow()
    override val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    override suspend fun start() {
        val settings = settingsRepository.settings.first()
        pollingJob?.cancel()
        pollingJob = scope.launch {
            if (settings.demoMode) pollDemo(settings) else pollVehicle(settings)
        }
    }

    override suspend fun stop() {
        pollingJob?.cancel()
        pollingJob = null
        elm327.disconnect()
        _connectionState.value = ConnectionState.Disconnected
    }

    private suspend fun pollDemo(settings: UserSettings) {
        _connectionState.value = ConnectionState.Connected("Simulation Renegade", demo = true)
        val start = System.currentTimeMillis()
        var distanceKm = 0.0
        var lastUpdate = start
        while (scope.isActive) {
            val now = System.currentTimeMillis()
            val elapsedSeconds = (now - start) / 1000.0
            val speed = (48 + 34 * sin(elapsedSeconds / 7.0)).toInt().coerceAtLeast(0)
            val rpm = (850 + speed * 31 + 240 * sin(elapsedSeconds / 2.2)).toInt().coerceAtLeast(750)
            distanceKm += speed * ((now - lastUpdate) / 3_600_000.0)
            lastUpdate = now
            _telemetry.value = VehicleTelemetry(
                timestampMillis = now,
                speedKph = speed,
                rpm = rpm,
                coolantCelsius = (88 + 5 * sin(elapsedSeconds / 20.0)).toInt(),
                fuelPercent = (76 - distanceKm * 0.35).toInt().coerceIn(0, 100),
                oilPressureBar = 2.2 + rpm / 4000.0,
                batteryVolts = 14.1 + 0.15 * sin(elapsedSeconds / 3.0),
                instantConsumptionLitresPer100Km = 6.5 + speed / 22.0,
                averageConsumptionLitresPer100Km = 8.2,
                outsideTemperatureCelsius = 23,
                latitude = 45.7640 + sin(elapsedSeconds / 120.0) / 1000.0,
                longitude = 4.8357 + sin(elapsedSeconds / 90.0) / 1000.0,
                gpsSpeedKph = (speed - 1).coerceAtLeast(0),
                tripDistanceKm = distanceKm,
                drivingSeconds = ((now - start) / 1000),
                indicators = if ((elapsedSeconds.toLong() / 15) % 2L == 1L) {
                    setOf(VehicleIndicator.ABS)
                } else {
                    emptySet()
                },
            )
            delay(settings.refreshIntervalMillis)
        }
    }

    private suspend fun pollVehicle(settings: UserSettings) {
        val address = settings.selectedDeviceAddress
        if (address == null) {
            _connectionState.value = ConnectionState.Error("Sélectionnez un module OBD-II")
            return
        }
        _connectionState.value = ConnectionState.Connecting
        try {
            elm327.ensureConnected(address)
            _connectionState.value = ConnectionState.Connected(
                settings.selectedDeviceName ?: "Module OBD-II",
                demo = false,
            )
            val start = System.currentTimeMillis()
            var last = System.currentTimeMillis()
            var distance = 0.0
            while (scope.isActive) {
                val now = System.currentTimeMillis()
                val speed = Elm327Parser.speedKph(elm327.query("010D"))
                val rpm = Elm327Parser.rpm(elm327.query("010C"))
                val current = _telemetry.value
                distance += speed * ((now - last) / 3_600_000.0)
                last = now
                _telemetry.value = current.copy(
                    timestampMillis = now,
                    speedKph = speed,
                    rpm = rpm,
                    coolantCelsius = readOr(current.coolantCelsius) {
                        Elm327Parser.coolantCelsius(elm327.query("0105"))
                    },
                    fuelPercent = readOr(current.fuelPercent) {
                        Elm327Parser.fuelPercent(elm327.query("012F"))
                    },
                    oilPressureBar = readOr(current.oilPressureBar) {
                        Elm327Parser.oilPressureBar(elm327.query("010A"))
                    },
                    batteryVolts = readOr(current.batteryVolts) {
                        Elm327Parser.voltage(elm327.query("ATRV"))
                    },
                    outsideTemperatureCelsius = readOr(current.outsideTemperatureCelsius) {
                        Elm327Parser.outsideTemperatureCelsius(elm327.query("0146"))
                    },
                    tripDistanceKm = distance,
                    drivingSeconds = (now - start) / 1000,
                )
                delay(settings.refreshIntervalMillis)
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Throwable) {
            _connectionState.value = ConnectionState.Error(
                error.message ?: "Connexion OBD-II interrompue",
            )
            elm327.disconnect()
        }
    }

    private suspend fun <T> readOr(fallback: T, block: suspend () -> T): T =
        runCatching { block() }.getOrDefault(fallback)
}

