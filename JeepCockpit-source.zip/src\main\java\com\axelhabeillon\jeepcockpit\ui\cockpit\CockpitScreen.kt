package com.axelhabeillon.jeepcockpit.ui.cockpit

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.OilBarrel
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.axelhabeillon.jeepcockpit.core.model.ConnectionState
import com.axelhabeillon.jeepcockpit.core.model.UnitSystem
import com.axelhabeillon.jeepcockpit.core.model.VehicleIndicator
import com.axelhabeillon.jeepcockpit.core.model.VehicleTelemetry
import com.axelhabeillon.jeepcockpit.ui.theme.JeepBorder
import com.axelhabeillon.jeepcockpit.ui.theme.JeepDarkGray
import com.axelhabeillon.jeepcockpit.ui.theme.JeepGreen
import com.axelhabeillon.jeepcockpit.ui.theme.JeepLightOrange
import com.axelhabeillon.jeepcockpit.ui.theme.JeepOrange
import com.axelhabeillon.jeepcockpit.ui.theme.JeepRed
import com.axelhabeillon.jeepcockpit.ui.theme.JeepTextGray
import java.util.Locale

@Composable
fun CockpitRoute(viewModel: CockpitViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    CockpitScreen(state)
}

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun CockpitScreen(state: CockpitUiState) {
    val telemetry = state.telemetry
    val (speed, speedUnit) = telemetry.displaySpeed(state.settings.unitSystem)
    val (distance, distanceUnit) = telemetry.displayDistance(state.settings.unitSystem)
    val (outsideTemperature, temperatureUnit) =
        telemetry.displayOutsideTemperature(state.settings.unitSystem)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .padding(horizontal = 16.dp),
    ) {
        Spacer(Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                Text("JEEP", color = JeepOrange, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("COCKPIT", style = MaterialTheme.typography.headlineLarge)
            }
            ConnectionBadge(state.connectionState)
        }

        telemetry.criticalMessage?.let { message ->
            Spacer(Modifier.height(12.dp))
            CriticalBanner(message)
        }

        Spacer(Modifier.height(16.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            CircularGauge(
                label = "VITESSE",
                value = speed.toFloat(),
                max = if (state.settings.unitSystem == UnitSystem.METRIC) 220f else 140f,
                valueText = speed.toString(),
                unit = speedUnit,
                modifier = Modifier.weight(1f),
            )
            CircularGauge(
                label = "RÉGIME",
                value = telemetry.rpm.toFloat(),
                max = 7_000f,
                valueText = telemetry.rpm.toString(),
                unit = "tr/min",
                dangerStartFraction = 6_000f / 7_000f,
                modifier = Modifier.weight(1f),
            )
        }

        Spacer(Modifier.height(16.dp))
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            maxItemsInEachRow = 2,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            TelemetryCard(
                "Moteur",
                "${telemetry.coolantCelsius} °C",
                Icons.Default.Thermostat,
                telemetry.coolantCelsius > 100,
                Modifier.weight(1f),
            )
            TelemetryCard(
                "Carburant",
                "${telemetry.fuelPercent} %",
                Icons.Default.LocalGasStation,
                telemetry.fuelPercent < 10,
                Modifier.weight(1f),
            )
            TelemetryCard(
                "Pression huile",
                format(telemetry.oilPressureBar, "bar"),
                Icons.Default.OilBarrel,
                telemetry.rpm > 500 && telemetry.oilPressureBar < 1.0,
                Modifier.weight(1f),
            )
            TelemetryCard(
                "Batterie",
                format(telemetry.batteryVolts, "V"),
                Icons.Default.BatteryChargingFull,
                telemetry.batteryVolts < 12.0,
                Modifier.weight(1f),
            )
            TelemetryCard(
                "Conso. instantanée",
                format(telemetry.instantConsumptionLitresPer100Km, "L/100"),
                Icons.Default.Speed,
                false,
                Modifier.weight(1f),
            )
            TelemetryCard(
                "Conso. moyenne",
                format(telemetry.averageConsumptionLitresPer100Km, "L/100"),
                Icons.Default.Speed,
                false,
                Modifier.weight(1f),
            )
            TelemetryCard(
                "Extérieur",
                "$outsideTemperature $temperatureUnit",
                Icons.Default.Thermostat,
                false,
                Modifier.weight(1f),
            )
            TelemetryCard(
                "Temps de roulage",
                formatDuration(telemetry.drivingSeconds),
                Icons.Default.Timer,
                false,
                Modifier.weight(1f),
            )
        }

        Spacer(Modifier.height(12.dp))
        TripAndGpsCard(telemetry, distance, distanceUnit)
        Spacer(Modifier.height(12.dp))
        IndicatorPanel(telemetry.indicators)
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun ConnectionBadge(state: ConnectionState) {
    val (label, color) = when (state) {
        ConnectionState.Disconnected -> "HORS LIGNE" to JeepTextGray
        ConnectionState.Connecting -> "CONNEXION..." to JeepLightOrange
        is ConnectionState.Connected -> if (state.demo) "MODE DÉMO" to JeepOrange else "CONNECTÉ" to JeepGreen
        is ConnectionState.Error -> "ERREUR" to JeepRed
    }
    Text(
        text = label,
        color = color,
        style = MaterialTheme.typography.labelLarge,
        modifier = Modifier
            .border(1.dp, color, RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 6.dp),
    )
}

@Composable
private fun CriticalBanner(message: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(JeepRed)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Default.Warning, contentDescription = null)
        Spacer(Modifier.width(10.dp))
        Text(message, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun CircularGauge(
    label: String,
    value: Float,
    max: Float,
    valueText: String,
    unit: String,
    modifier: Modifier = Modifier,
    dangerStartFraction: Float? = null,
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = JeepDarkGray),
        border = CardDefaults.outlinedCardBorder(),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .semantics { contentDescription = "$label $valueText $unit" },
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.size(145.dp)) {
                val stroke = 11.dp.toPx()
                val inset = stroke / 2
                val arcSize = Size(size.width - stroke, size.height - stroke)
                drawArc(
                    color = JeepBorder,
                    startAngle = 135f,
                    sweepAngle = 270f,
                    useCenter = false,
                    topLeft = Offset(inset, inset),
                    size = arcSize,
                    style = Stroke(stroke, cap = StrokeCap.Round),
                )
                dangerStartFraction?.let { start ->
                    drawArc(
                        color = JeepRed,
                        startAngle = 135f + 270f * start,
                        sweepAngle = 270f * (1f - start),
                        useCenter = false,
                        topLeft = Offset(inset, inset),
                        size = arcSize,
                        style = Stroke(stroke, cap = StrokeCap.Round),
                    )
                }
                drawArc(
                    color = if (dangerStartFraction != null && value / max >= dangerStartFraction) JeepRed else JeepOrange,
                    startAngle = 135f,
                    sweepAngle = 270f * (value / max).coerceIn(0f, 1f),
                    useCenter = false,
                    topLeft = Offset(inset, inset),
                    size = arcSize,
                    style = Stroke(stroke, cap = StrokeCap.Round),
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(label, color = JeepTextGray, style = MaterialTheme.typography.labelLarge)
                Text(valueText, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text(unit, color = JeepTextGray, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun TelemetryCard(
    label: String,
    value: String,
    icon: ImageVector,
    critical: Boolean,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = JeepDarkGray),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(if (critical) JeepRed else JeepBorder, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, contentDescription = null, tint = if (critical) Color.White else JeepOrange)
            }
            Spacer(Modifier.width(10.dp))
            Column {
                Text(label, color = JeepTextGray, fontSize = 11.sp)
                Text(value, fontWeight = FontWeight.Bold, color = if (critical) JeepRed else Color.White)
            }
        }
    }
}

@Composable
private fun TripAndGpsCard(telemetry: VehicleTelemetry, distance: Double, distanceUnit: String) {
    Card(colors = CardDefaults.cardColors(containerColor = JeepDarkGray)) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.GpsFixed, contentDescription = null, tint = JeepOrange)
                Spacer(Modifier.width(8.dp))
                Text("TRAJET & GPS", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Distance", color = JeepTextGray)
                Text(format(distance, distanceUnit), fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(5.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Position", color = JeepTextGray)
                Text(
                    if (telemetry.latitude != null && telemetry.longitude != null) {
                        String.format(Locale.FRANCE, "%.4f, %.4f", telemetry.latitude, telemetry.longitude)
                    } else {
                        "Indisponible"
                    },
                    textAlign = TextAlign.End,
                )
            }
        }
    }
}

@Composable
private fun IndicatorPanel(active: Set<VehicleIndicator>) {
    Card(colors = CardDefaults.cardColors(containerColor = JeepDarkGray)) {
        Column(Modifier.padding(14.dp)) {
            Text("VOYANTS", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                VehicleIndicator.entries.forEach { indicator ->
                    val enabled = indicator in active
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(26.dp)
                                .background(if (enabled) JeepRed else JeepBorder, CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            if (enabled) Text("!", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Text(indicator.label, fontSize = 9.sp, color = if (enabled) JeepRed else JeepTextGray)
                    }
                }
            }
        }
    }
}

private fun format(value: Double, unit: String): String =
    String.format(Locale.FRANCE, "%.1f %s", value, unit)

private fun formatDuration(seconds: Long): String =
    "%02d:%02d:%02d".format(seconds / 3600, (seconds % 3600) / 60, seconds % 60)
