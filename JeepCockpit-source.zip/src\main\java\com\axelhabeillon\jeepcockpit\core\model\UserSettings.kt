package com.axelhabeillon.jeepcockpit.core.model

data class UserSettings(
    val demoMode: Boolean = true,
    val selectedDeviceAddress: String? = null,
    val selectedDeviceName: String? = null,
    val unitSystem: UnitSystem = UnitSystem.METRIC,
    val refreshIntervalMillis: Long = 500L,
    val notificationsEnabled: Boolean = true,
)

enum class UnitSystem(val label: String) {
    METRIC("Métrique"),
    IMPERIAL("Impérial"),
}

data class BluetoothDeviceInfo(
    val name: String,
    val address: String,
)

