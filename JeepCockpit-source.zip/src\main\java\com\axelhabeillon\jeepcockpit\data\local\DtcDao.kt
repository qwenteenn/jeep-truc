package com.axelhabeillon.jeepcockpit.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface DtcDao {
    @Query("SELECT * FROM dtc_history WHERE active = 1 ORDER BY detectedAtMillis DESC")
    fun observeActive(): Flow<List<DtcEntity>>

    @Query("SELECT * FROM dtc_history ORDER BY detectedAtMillis DESC LIMIT 250")
    fun observeHistory(): Flow<List<DtcEntity>>

    @Query("SELECT code FROM dtc_history WHERE active = 1")
    suspend fun activeCodes(): List<String>

    @Query("UPDATE dtc_history SET active = 0 WHERE active = 1")
    suspend fun deactivateAll()

    @Insert
    suspend fun insertAll(codes: List<DtcEntity>)

    @Transaction
    suspend fun replaceActive(codes: List<DtcEntity>) {
        deactivateAll()
        if (codes.isNotEmpty()) insertAll(codes)
    }
}

