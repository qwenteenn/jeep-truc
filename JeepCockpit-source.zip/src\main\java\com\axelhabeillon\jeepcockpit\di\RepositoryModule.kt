package com.axelhabeillon.jeepcockpit.di

import com.axelhabeillon.jeepcockpit.core.repository.DiagnosticRepository
import com.axelhabeillon.jeepcockpit.core.repository.SettingsRepository
import com.axelhabeillon.jeepcockpit.core.repository.VehicleRepository
import com.axelhabeillon.jeepcockpit.data.repository.DiagnosticRepositoryImpl
import com.axelhabeillon.jeepcockpit.data.repository.VehicleRepositoryImpl
import com.axelhabeillon.jeepcockpit.data.settings.SettingsRepositoryImpl
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {
    @Binds
    @Singleton
    abstract fun bindVehicleRepository(implementation: VehicleRepositoryImpl): VehicleRepository

    @Binds
    @Singleton
    abstract fun bindDiagnosticRepository(implementation: DiagnosticRepositoryImpl): DiagnosticRepository

    @Binds
    @Singleton
    abstract fun bindSettingsRepository(implementation: SettingsRepositoryImpl): SettingsRepository
}

