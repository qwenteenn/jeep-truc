# État de livraison et suite recommandée

## Périmètre réellement implémenté

Le projet constitue un MVP Android compilable couvrant les trois écrans demandés : Cockpit, Scanner DTC et Réglages. Le mode démo rend le flux entièrement testable sans dongle. La couche ELM327 communique par Bluetooth RFCOMM et isole l'accès matériel derrière les repositories.

## Validations terrain encore nécessaires

1. Vérifier le profil Bluetooth du modèle Veepeak exact (certains modèles BLE ne parlent pas RFCOMM SPP).
2. Mesurer les temps de réponse des PID sur la Jeep Renegade 2016 et ajuster l'ordonnancement : une boucle à 10 Hz n'est pas réaliste si plusieurs PID sont interrogés séquentiellement.
3. Confirmer la disponibilité des PID `010A`, `012F` et `0146` sur le calculateur.
4. Tester la commande `04` moteur arrêté, contact mis, avec un défaut de test documenté.
5. Ajouter les tests instrumentés sur téléphone Android 8, Android 12 et Android 14.
6. Brancher un fournisseur GPS réel et les notifications critiques si ces fonctions sont requises pour la V1 de production.

## Décisions durables

- Mode démo par défaut : évite toute tentative automatique de connexion ou d'action sur un véhicule.
- Portrait verrouillé conformément au cahier des charges.
- `minSdk 26`, `targetSdk 34`, Java 17.
- Base Room locale uniquement ; aucune donnée n'est envoyée sur Internet.
- Effacement DTC explicitement confirmé par l'utilisateur.
