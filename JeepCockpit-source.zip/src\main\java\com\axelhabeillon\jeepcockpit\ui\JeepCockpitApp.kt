package com.axelhabeillon.jeepcockpit.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.axelhabeillon.jeepcockpit.ui.cockpit.CockpitRoute
import com.axelhabeillon.jeepcockpit.ui.scanner.ScannerRoute
import com.axelhabeillon.jeepcockpit.ui.settings.SettingsRoute
import com.axelhabeillon.jeepcockpit.ui.theme.JeepDarkGray
import com.axelhabeillon.jeepcockpit.ui.theme.JeepOrange

private enum class Destination(
    val route: String,
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
) {
    Cockpit("cockpit", "Cockpit", Icons.Default.Dashboard),
    Scanner("scanner", "Défauts", Icons.Default.Warning),
    Settings("settings", "Réglages", Icons.Default.Settings),
}

@Composable
fun JeepCockpitApp() {
    val navController = rememberNavController()
    val entry by navController.currentBackStackEntryAsState()
    val currentRoute = entry?.destination?.route

    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = JeepDarkGray) {
                Destination.entries.forEach { destination ->
                    NavigationBarItem(
                        selected = currentRoute == destination.route,
                        onClick = {
                            navController.navigate(destination.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = {
                            Icon(destination.icon, contentDescription = destination.label)
                        },
                        label = { Text(destination.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = JeepOrange,
                            selectedTextColor = JeepOrange,
                            indicatorColor = JeepDarkGray,
                        ),
                    )
                }
            }
        },
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Destination.Cockpit.route,
            modifier = Modifier.padding(padding),
        ) {
            composable(Destination.Cockpit.route) { CockpitRoute() }
            composable(Destination.Scanner.route) { ScannerRoute() }
            composable(Destination.Settings.route) { SettingsRoute() }
        }
    }
}
