package com.axelhabeillon.jeepcockpit.ui.scanner

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.axelhabeillon.jeepcockpit.core.model.DtcCode
import com.axelhabeillon.jeepcockpit.core.model.DtcSeverity
import com.axelhabeillon.jeepcockpit.domain.ManageDiagnosticsUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject

enum class DtcListMode(val label: String) {
    ACTIVE("Actifs"),
    HISTORY("Historique"),
}

data class ScannerUiState(
    val codes: List<DtcCode> = emptyList(),
    val query: String = "",
    val severity: DtcSeverity? = null,
    val mode: DtcListMode = DtcListMode.ACTIVE,
    val isLoading: Boolean = false,
    val message: String? = null,
)

@HiltViewModel
class ScannerViewModel @Inject constructor(
    private val diagnostics: ManageDiagnosticsUseCase,
) : ViewModel() {
    private val query = MutableStateFlow("")
    private val severity = MutableStateFlow<DtcSeverity?>(null)
    private val mode = MutableStateFlow(DtcListMode.ACTIVE)
    private val loading = MutableStateFlow(false)
    private val message = MutableStateFlow<String?>(null)

    val uiState = combine(
        diagnostics.activeCodes(),
        diagnostics.history(),
        query,
        severity,
        mode,
    ) { active, history, queryValue, severityValue, modeValue ->
        val source = if (modeValue == DtcListMode.ACTIVE) active else history
        ScannerUiState(
            codes = source.filter { code ->
                (severityValue == null || code.severity == severityValue) &&
                    (queryValue.isBlank() ||
                        code.code.contains(queryValue, ignoreCase = true) ||
                        code.description.contains(queryValue, ignoreCase = true))
            },
            query = queryValue,
            severity = severityValue,
            mode = modeValue,
        )
    }.combine(loading) { state, isLoading -> state.copy(isLoading = isLoading) }
        .combine(message) { state, currentMessage -> state.copy(message = currentMessage) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = ScannerUiState(),
        )

    init {
        scan()
    }

    fun setQuery(value: String) {
        query.value = value
    }

    fun setSeverity(value: DtcSeverity?) {
        severity.value = value
    }

    fun setMode(value: DtcListMode) {
        mode.value = value
    }

    fun scan() {
        viewModelScope.launch {
            loading.value = true
            diagnostics.scan()
                .onSuccess { message.value = "Scan terminé : ${it.size} code(s) détecté(s)" }
                .onFailure { message.value = it.message ?: "Échec du scan" }
            loading.value = false
        }
    }

    fun clear() {
        viewModelScope.launch {
            loading.value = true
            diagnostics.clear()
                .onSuccess { message.value = "Codes effacés avec succès" }
                .onFailure { message.value = it.message ?: "Échec de l'effacement" }
            loading.value = false
        }
    }

    fun consumeMessage() {
        message.value = null
    }

    fun exportCsv(codes: List<DtcCode>): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.FRANCE)
        return buildString {
            appendLine("code;description;gravite;causes_probables;action;detecte_le")
            codes.forEach { code ->
                appendLine(
                    listOf(
                        code.code,
                        code.description,
                        code.severity.label,
                        code.probableCauses,
                        code.suggestedAction,
                        dateFormat.format(Date(code.detectedAtMillis)),
                    ).joinToString(";") { csvCell(it) },
                )
            }
        }
    }

    private fun csvCell(value: String): String = "\"${value.replace("\"", "\"\"")}\""
}

