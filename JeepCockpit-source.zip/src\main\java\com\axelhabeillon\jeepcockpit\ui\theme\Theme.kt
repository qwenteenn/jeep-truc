package com.axelhabeillon.jeepcockpit.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val JeepColorScheme = darkColorScheme(
    primary = JeepOrange,
    onPrimary = JeepBlack,
    secondary = JeepGreen,
    onSecondary = JeepBlack,
    error = JeepRed,
    background = JeepBlack,
    onBackground = JeepWhite,
    surface = JeepDarkGray,
    onSurface = JeepWhite,
    outline = JeepBorder,
)

@Composable
fun JeepCockpitTheme(
    @Suppress("UNUSED_PARAMETER") darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = JeepBlack.toArgb()
            window.navigationBarColor = JeepBlack.toArgb()
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = false
                isAppearanceLightNavigationBars = false
            }
        }
    }
    MaterialTheme(
        colorScheme = JeepColorScheme,
        typography = JeepTypography,
        content = content,
    )
}

