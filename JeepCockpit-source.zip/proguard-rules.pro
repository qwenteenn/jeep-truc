# Jeep Cockpit currently keeps release symbols to simplify field diagnostics.

