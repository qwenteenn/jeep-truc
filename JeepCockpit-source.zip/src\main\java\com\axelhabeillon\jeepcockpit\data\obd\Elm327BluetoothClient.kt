package com.axelhabeillon.jeepcockpit.data.obd

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class Elm327BluetoothClient @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val mutex = Mutex()
    private var socket: BluetoothSocket? = null
    private var connectedAddress: String? = null

    val isConnected: Boolean
        get() = socket?.isConnected == true

    suspend fun ensureConnected(address: String) = mutex.withLock {
        if (isConnected && connectedAddress == address) return@withLock
        closeUnsafe()
        connectUnsafe(address)
    }

    suspend fun query(command: String): String = mutex.withLock {
        check(isConnected) { "Module OBD-II non connecté" }
        exchangeUnsafe(command)
    }

    suspend fun clearCodes() {
        val response = query("04")
        check("44" in response.replace(" ", "")) { "Le calculateur n'a pas confirmé l'effacement" }
    }

    suspend fun disconnect() = mutex.withLock { closeUnsafe() }

    @SuppressLint("MissingPermission")
    private suspend fun connectUnsafe(address: String) = withContext(Dispatchers.IO) {
        requireBluetoothPermission()
        val adapter = context.getSystemService(BluetoothManager::class.java)?.adapter
            ?: error("Bluetooth indisponible")
        check(adapter.isEnabled) { "Bluetooth désactivé" }
        val device = adapter.getRemoteDevice(address)
        val newSocket = device.createRfcommSocketToServiceRecord(SPP_UUID)
        try {
            adapter.cancelDiscovery()
            newSocket.connect()
            socket = newSocket
            connectedAddress = address
            listOf("ATZ", "ATE0", "ATL0", "ATS0", "ATH0", "ATSP0").forEach {
                exchangeUnsafe(it)
            }
        } catch (error: Throwable) {
            runCatching { newSocket.close() }
            socket = null
            connectedAddress = null
            throw error
        }
    }

    private fun exchangeUnsafe(command: String): String {
        val activeSocket = socket ?: error("Module OBD-II non connecté")
        activeSocket.outputStream.apply {
            write("$command\r".toByteArray(Charsets.US_ASCII))
            flush()
        }
        val buffer = ByteArrayOutputStream()
        while (true) {
            val byte = activeSocket.inputStream.read()
            check(byte >= 0) { "Connexion OBD-II interrompue" }
            if (byte.toChar() == '>') break
            buffer.write(byte)
        }
        return buffer.toString(Charsets.US_ASCII.name()).trim()
    }

    private fun closeUnsafe() {
        runCatching { socket?.close() }
        socket = null
        connectedAddress = null
    }

    private fun requireBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            check(
                ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) ==
                    PackageManager.PERMISSION_GRANTED,
            ) { "Autorisation Bluetooth requise" }
        }
    }

    private companion object {
        val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }
}

