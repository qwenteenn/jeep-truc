package com.axelhabeillon.jeepcockpit.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.axelhabeillon.jeepcockpit.core.model.DtcCode
import com.axelhabeillon.jeepcockpit.core.model.DtcSeverity

@Entity(tableName = "dtc_history")
data class DtcEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: String,
    val description: String,
    val severity: String,
    val probableCauses: String,
    val suggestedAction: String,
    val detectedAtMillis: Long,
    val active: Boolean,
)

fun DtcEntity.toDomain() = DtcCode(
    code = code,
    description = description,
    severity = runCatching { DtcSeverity.valueOf(severity) }.getOrDefault(DtcSeverity.MEDIUM),
    probableCauses = probableCauses,
    suggestedAction = suggestedAction,
    detectedAtMillis = detectedAtMillis,
)

fun DtcCode.toEntity(active: Boolean) = DtcEntity(
    code = code,
    description = description,
    severity = severity.name,
    probableCauses = probableCauses,
    suggestedAction = suggestedAction,
    detectedAtMillis = detectedAtMillis,
    active = active,
)

