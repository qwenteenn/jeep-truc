package com.axelhabeillon.jeepcockpit.core.repository

import com.axelhabeillon.jeepcockpit.core.model.BluetoothDeviceInfo
import com.axelhabeillon.jeepcockpit.core.model.UnitSystem
import com.axelhabeillon.jeepcockpit.core.model.UserSettings
import kotlinx.coroutines.flow.Flow

interface SettingsRepository {
    val settings: Flow<UserSettings>

    suspend fun setDemoMode(enabled: Boolean)
    suspend fun setSelectedDevice(device: BluetoothDeviceInfo)
    suspend fun setUnitSystem(unitSystem: UnitSystem)
    suspend fun setRefreshInterval(milliseconds: Long)
    suspend fun setNotificationsEnabled(enabled: Boolean)
    fun bondedDevices(): Result<List<BluetoothDeviceInfo>>
}
