package com.axelhabeillon.jeepcockpit.data.repository

import com.axelhabeillon.jeepcockpit.core.model.DtcCatalog
import com.axelhabeillon.jeepcockpit.core.model.DtcCode
import com.axelhabeillon.jeepcockpit.core.repository.DiagnosticRepository
import com.axelhabeillon.jeepcockpit.core.repository.SettingsRepository
import com.axelhabeillon.jeepcockpit.data.local.DtcDao
import com.axelhabeillon.jeepcockpit.data.local.toDomain
import com.axelhabeillon.jeepcockpit.data.local.toEntity
import com.axelhabeillon.jeepcockpit.data.obd.Elm327BluetoothClient
import com.axelhabeillon.jeepcockpit.data.obd.Elm327Parser
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DiagnosticRepositoryImpl @Inject constructor(
    private val dao: DtcDao,
    private val settingsRepository: SettingsRepository,
    private val elm327: Elm327BluetoothClient,
) : DiagnosticRepository {
    override fun observeActiveCodes(): Flow<List<DtcCode>> =
        dao.observeActive().map { entities -> entities.map { it.toDomain() } }

    override fun observeHistory(): Flow<List<DtcCode>> =
        dao.observeHistory().map { entities -> entities.map { it.toDomain() } }

    override suspend fun scan(): Result<List<DtcCode>> = runCatching {
        val settings = settingsRepository.settings.first()
        val detected = if (settings.demoMode) {
            listOf("P0442", "P0130", "P1C5F").map(DtcCatalog::describe)
        } else {
            val address = settings.selectedDeviceAddress ?: error("Sélectionnez un module OBD-II")
            elm327.ensureConnected(address)
            Elm327Parser.dtcCodes(elm327.query("03")).map(DtcCatalog::describe)
        }
        val timestamped = detected.map { it.copy(detectedAtMillis = System.currentTimeMillis()) }
        dao.replaceActive(timestamped.map { it.toEntity(active = true) })
        timestamped
    }

    override suspend fun clear(): Result<Unit> = runCatching {
        val settings = settingsRepository.settings.first()
        if (!settings.demoMode) {
            val address = settings.selectedDeviceAddress ?: error("Sélectionnez un module OBD-II")
            elm327.ensureConnected(address)
            elm327.clearCodes()
        }
        dao.deactivateAll()
    }
}
