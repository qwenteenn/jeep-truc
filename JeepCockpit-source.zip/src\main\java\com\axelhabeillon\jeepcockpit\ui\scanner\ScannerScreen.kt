package com.axelhabeillon.jeepcockpit.ui.scanner

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.axelhabeillon.jeepcockpit.core.model.DtcCode
import com.axelhabeillon.jeepcockpit.core.model.DtcSeverity
import com.axelhabeillon.jeepcockpit.ui.theme.JeepDarkGray
import com.axelhabeillon.jeepcockpit.ui.theme.JeepGreen
import com.axelhabeillon.jeepcockpit.ui.theme.JeepLightOrange
import com.axelhabeillon.jeepcockpit.ui.theme.JeepOrange
import com.axelhabeillon.jeepcockpit.ui.theme.JeepRed
import com.axelhabeillon.jeepcockpit.ui.theme.JeepTextGray

@Composable
fun ScannerRoute(viewModel: ScannerViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    ScannerScreen(
        state = state,
        onQueryChange = viewModel::setQuery,
        onSeverityChange = viewModel::setSeverity,
        onModeChange = viewModel::setMode,
        onScan = viewModel::scan,
        onClear = viewModel::clear,
        onMessageConsumed = viewModel::consumeMessage,
        exportCsv = viewModel::exportCsv,
    )
}

@Composable
fun ScannerScreen(
    state: ScannerUiState,
    onQueryChange: (String) -> Unit,
    onSeverityChange: (DtcSeverity?) -> Unit,
    onModeChange: (DtcListMode) -> Unit,
    onScan: () -> Unit,
    onClear: () -> Unit,
    onMessageConsumed: () -> Unit,
    exportCsv: (List<DtcCode>) -> String,
) {
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current
    var confirmClear by remember { mutableStateOf(false) }
    var pendingExport by remember { mutableStateOf("") }
    val createDocument = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv"),
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use {
                    it.write(pendingExport.toByteArray(Charsets.UTF_8))
                } ?: error("Impossible d'ouvrir le fichier")
            }
        }
    }

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbarHostState.showSnackbar(it)
            onMessageConsumed()
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = JeepRed) },
            title = { Text("Effacer les codes ?") },
            text = { Text("Cette commande réinitialise les défauts dans le calculateur. Ils peuvent réapparaître si la cause persiste.") },
            confirmButton = {
                Button(
                    onClick = {
                        confirmClear = false
                        onClear()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = JeepRed),
                ) { Text("EFFACER") }
            },
            dismissButton = {
                Button(onClick = { confirmClear = false }) { Text("ANNULER") }
            },
        )
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .statusBarsPadding()
                .padding(padding)
                .padding(horizontal = 16.dp),
        ) {
            Spacer(Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column {
                    Text("DIAGNOSTIC", color = JeepOrange, fontWeight = FontWeight.Bold)
                    Text("Scanner DTC", style = MaterialTheme.typography.headlineLarge)
                }
                Row {
                    IconButton(
                        onClick = {
                            pendingExport = exportCsv(state.codes)
                            createDocument.launch("jeep-dtc.csv")
                        },
                        enabled = state.codes.isNotEmpty(),
                    ) {
                        Icon(Icons.Default.Download, contentDescription = "Exporter en CSV")
                    }
                    IconButton(onClick = onScan, enabled = !state.isLoading) {
                        Icon(Icons.Default.Refresh, contentDescription = "Rafraîchir")
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                value = state.query,
                onValueChange = onQueryChange,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Rechercher un code ou une description") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            )

            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DtcListMode.entries.forEach { mode ->
                    FilterChip(
                        selected = state.mode == mode,
                        onClick = { onModeChange(mode) },
                        label = { Text(mode.label) },
                        leadingIcon = if (mode == DtcListMode.HISTORY) {
                            { Icon(Icons.Default.History, contentDescription = null, Modifier.size(16.dp)) }
                        } else null,
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                AssistChip(
                    onClick = { onSeverityChange(null) },
                    label = { Text("Toutes") },
                )
                DtcSeverity.entries.forEach { severity ->
                    FilterChip(
                        selected = state.severity == severity,
                        onClick = {
                            onSeverityChange(if (state.severity == severity) null else severity)
                        },
                        label = { Text(severity.label) },
                    )
                }
            }

            Spacer(Modifier.height(8.dp))
            if (state.isLoading && state.codes.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    CircularProgressIndicator(color = JeepOrange)
                    Spacer(Modifier.height(10.dp))
                    Text("Interrogation du calculateur...", color = JeepTextGray)
                }
            } else if (state.codes.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = JeepGreen, modifier = Modifier.size(46.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("Aucun code correspondant", fontWeight = FontWeight.Bold)
                    Text("Le calculateur ne signale aucun défaut dans cette vue.", color = JeepTextGray)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(state.codes, key = { "${it.code}-${it.detectedAtMillis}" }) { code ->
                        DtcCard(code)
                    }
                    item { Spacer(Modifier.height(4.dp)) }
                }
            }

            if (state.mode == DtcListMode.ACTIVE) {
                Button(
                    onClick = { confirmClear = true },
                    enabled = state.codes.isNotEmpty() && !state.isLoading,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = JeepRed),
                ) {
                    Icon(Icons.Default.DeleteForever, contentDescription = null)
                    Text(" EFFACER LES CODES")
                }
            }
        }
    }
}

@Composable
private fun DtcCard(code: DtcCode) {
    val severityColor = when (code.severity) {
        DtcSeverity.LOW -> JeepGreen
        DtcSeverity.MEDIUM -> JeepLightOrange
        DtcSeverity.HIGH, DtcSeverity.CRITICAL -> JeepRed
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = JeepDarkGray),
        shape = RoundedCornerShape(12.dp),
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Spacer(
                        Modifier
                            .size(10.dp)
                            .background(severityColor, CircleShape),
                    )
                    Text("  ${code.code}", color = severityColor, fontWeight = FontWeight.Bold)
                }
                Text(code.severity.label.uppercase(), color = severityColor, style = MaterialTheme.typography.labelLarge)
            }
            Spacer(Modifier.height(8.dp))
            Text(code.description, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("CAUSES PROBABLES", color = JeepTextGray, style = MaterialTheme.typography.labelLarge)
            Text(code.probableCauses, maxLines = 3, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(6.dp))
            Text("ACTION CONSEILLÉE", color = JeepTextGray, style = MaterialTheme.typography.labelLarge)
            Text(code.suggestedAction)
        }
    }
}
