package com.axelhabeillon.jeepcockpit.data.obd

object Elm327Parser {
    fun speedKph(response: String): Int = payload(response, "410D")
        .firstOrNull()
        ?: error("Réponse vitesse invalide: $response")

    fun rpm(response: String): Int {
        val bytes = payload(response, "410C")
        require(bytes.size >= 2) { "Réponse RPM invalide: $response" }
        return ((bytes[0] shl 8) + bytes[1]) / 4
    }

    fun coolantCelsius(response: String): Int = payload(response, "4105")
        .firstOrNull()
        ?.minus(40)
        ?: error("Réponse température invalide: $response")

    fun fuelPercent(response: String): Int = payload(response, "412F")
        .firstOrNull()
        ?.let { (it * 100 / 255.0).toInt() }
        ?: error("Réponse carburant invalide: $response")

    fun oilPressureBar(response: String): Double = payload(response, "410A")
        .firstOrNull()
        ?.let { it * 3.0 / 100.0 }
        ?: error("Réponse pression d'huile invalide: $response")

    fun outsideTemperatureCelsius(response: String): Int = payload(response, "4146")
        .firstOrNull()
        ?.minus(40)
        ?: error("Réponse température extérieure invalide: $response")

    fun voltage(response: String): Double {
        val cleaned = response.uppercase()
            .replace("ATRV", "")
            .replace(">", "")
            .trim()
        return Regex("([0-9]+(?:[.,][0-9]+)?)\\s*V")
            .find(cleaned)
            ?.groupValues
            ?.get(1)
            ?.replace(',', '.')
            ?.toDouble()
            ?: error("Réponse tension invalide: $response")
    }

    fun dtcCodes(response: String): List<String> {
        val normalized = normalize(response)
        val marker = normalized.indexOf("43")
        if (marker < 0) return emptyList()
        return normalized.drop(marker + 2)
            .chunked(4)
            .mapNotNull { raw ->
                if (raw.length != 4 || raw == "0000") return@mapNotNull null
                val first = raw.substring(0, 2).toIntOrNull(16) ?: return@mapNotNull null
                val second = raw.substring(2, 4).toIntOrNull(16) ?: return@mapNotNull null
                val family = "PCBU"[(first and 0xC0) shr 6]
                val digit1 = (first and 0x30) shr 4
                val digit2 = first and 0x0F
                "$family$digit1${digit2.toString(16)}${(second shr 4).toString(16)}${(second and 0x0F).toString(16)}"
                    .uppercase()
            }
    }

    private fun payload(response: String, header: String): List<Int> {
        val normalized = normalize(response)
        val start = normalized.indexOf(header)
        if (start < 0) return emptyList()
        return normalized.drop(start + header.length)
            .chunked(2)
            .mapNotNull { it.takeIf { pair -> pair.length == 2 }?.toIntOrNull(16) }
    }

    private fun normalize(response: String): String = response.uppercase()
        .replace("SEARCHING...", "")
        .replace(Regex("[^0-9A-F]"), "")
}

