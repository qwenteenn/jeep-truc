package com.axelhabeillon.jeepcockpit.core.repository

import com.axelhabeillon.jeepcockpit.core.model.ConnectionState
import com.axelhabeillon.jeepcockpit.core.model.VehicleTelemetry
import kotlinx.coroutines.flow.StateFlow

interface VehicleRepository {
    val telemetry: StateFlow<VehicleTelemetry>
    val connectionState: StateFlow<ConnectionState>

    suspend fun start()
    suspend fun stop()
}

