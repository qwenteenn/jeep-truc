package com.axelhabeillon.jeepcockpit.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trips")
data class TripEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val startedAtMillis: Long,
    val endedAtMillis: Long,
    val distanceKm: Double,
    val averageConsumptionLitresPer100Km: Double,
)

