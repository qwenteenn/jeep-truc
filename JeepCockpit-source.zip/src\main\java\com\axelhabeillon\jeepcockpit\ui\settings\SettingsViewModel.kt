package com.axelhabeillon.jeepcockpit.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.axelhabeillon.jeepcockpit.core.model.BluetoothDeviceInfo
import com.axelhabeillon.jeepcockpit.core.model.UnitSystem
import com.axelhabeillon.jeepcockpit.core.model.UserSettings
import com.axelhabeillon.jeepcockpit.core.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsUiState(
    val settings: UserSettings = UserSettings(),
    val bondedDevices: List<BluetoothDeviceInfo> = emptyList(),
    val isLoadingDevices: Boolean = false,
    val message: String? = null,
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val repository: SettingsRepository,
) : ViewModel() {
    private val devices = MutableStateFlow<List<BluetoothDeviceInfo>>(emptyList())
    private val loading = MutableStateFlow(false)
    private val message = MutableStateFlow<String?>(null)

    val uiState = combine(repository.settings, devices, loading, message) {
            settings, deviceList, isLoading, currentMessage ->
        SettingsUiState(settings, deviceList, isLoading, currentMessage)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = SettingsUiState(),
    )

    fun setDemoMode(enabled: Boolean) = update { repository.setDemoMode(enabled) }
    fun setUnitSystem(unitSystem: UnitSystem) = update { repository.setUnitSystem(unitSystem) }
    fun setRefreshInterval(milliseconds: Long) = update { repository.setRefreshInterval(milliseconds) }
    fun setNotifications(enabled: Boolean) = update { repository.setNotificationsEnabled(enabled) }
    fun selectDevice(device: BluetoothDeviceInfo) = update {
        repository.setSelectedDevice(device)
        message.value = "Module ${device.name} sélectionné"
    }

    fun loadBondedDevices() {
        viewModelScope.launch {
            loading.value = true
            repository.bondedDevices()
                .onSuccess {
                    devices.value = it
                    if (it.isEmpty()) message.value = "Aucun module Bluetooth appairé"
                }
                .onFailure { message.value = it.message ?: "Impossible de lire les appareils" }
            loading.value = false
        }
    }

    fun consumeMessage() {
        message.value = null
    }

    private fun update(block: suspend () -> Unit) {
        viewModelScope.launch {
            runCatching { block() }
                .onFailure { message.value = it.message ?: "Paramètre non enregistré" }
        }
    }
}

