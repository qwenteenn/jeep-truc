package com.axelhabeillon.jeepcockpit.domain

import com.axelhabeillon.jeepcockpit.core.repository.DiagnosticRepository
import javax.inject.Inject

class ManageDiagnosticsUseCase @Inject constructor(
    private val repository: DiagnosticRepository,
) {
    fun activeCodes() = repository.observeActiveCodes()
    fun history() = repository.observeHistory()
    suspend fun scan() = repository.scan()
    suspend fun clear() = repository.clear()
}
