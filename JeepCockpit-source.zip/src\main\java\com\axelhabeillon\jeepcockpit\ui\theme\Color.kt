package com.axelhabeillon.jeepcockpit.ui.theme

import androidx.compose.ui.graphics.Color

val JeepBlack = Color(0xFF121212)
val JeepDarkGray = Color(0xFF1E1E1E)
val JeepBorder = Color(0xFF333333)
val JeepOrange = Color(0xFFFF6F00)
val JeepLightOrange = Color(0xFFFF9800)
val JeepGreen = Color(0xFF4CAF50)
val JeepRed = Color(0xFFF44336)
val JeepWhite = Color(0xFFFFFFFF)
val JeepTextGray = Color(0xFFE0E0E0)

