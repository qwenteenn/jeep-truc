package com.axelhabeillon.jeepcockpit.core.repository

import com.axelhabeillon.jeepcockpit.core.model.DtcCode
import kotlinx.coroutines.flow.Flow

interface DiagnosticRepository {
    fun observeActiveCodes(): Flow<List<DtcCode>>
    fun observeHistory(): Flow<List<DtcCode>>
    suspend fun scan(): Result<List<DtcCode>>
    suspend fun clear(): Result<Unit>
}

