package com.axelhabeillon.jeepcockpit.core.model

data class DtcCode(
    val code: String,
    val description: String,
    val severity: DtcSeverity,
    val probableCauses: String,
    val suggestedAction: String,
    val detectedAtMillis: Long = System.currentTimeMillis(),
)

enum class DtcSeverity(val label: String, val rank: Int) {
    LOW("Faible", 0),
    MEDIUM("Moyenne", 1),
    HIGH("Élevée", 2),
    CRITICAL("Critique", 3),
}

object DtcCatalog {
    val known = listOf(
        DtcCode(
            code = "P0300",
            description = "Ratés d'allumage aléatoires (multi-cylindres)",
            severity = DtcSeverity.HIGH,
            probableCauses = "Bougies usées ou bobines défectueuses",
            suggestedAction = "Contrôler puis remplacer les bougies",
        ),
        DtcCode(
            code = "P0420",
            description = "Efficacité du catalyseur sous le seuil",
            severity = DtcSeverity.HIGH,
            probableCauses = "Catalyseur saturé ou défectueux",
            suggestedAction = "Contrôler le catalyseur et les sondes lambda",
        ),
        DtcCode(
            code = "P0171",
            description = "Mélange trop pauvre - Bank 1",
            severity = DtcSeverity.HIGH,
            probableCauses = "Fuite d'air ou capteur MAF défectueux",
            suggestedAction = "Vérifier l'admission et les durites",
        ),
        DtcCode(
            code = "P0442",
            description = "Petite fuite dans le système EVAP",
            severity = DtcSeverity.LOW,
            probableCauses = "Bouchon de réservoir mal fermé",
            suggestedAction = "Resserrer et inspecter le bouchon",
        ),
        DtcCode(
            code = "P0130",
            description = "Sonde lambda O2 - défaut de circuit",
            severity = DtcSeverity.MEDIUM,
            probableCauses = "Sonde défectueuse ou câblage coupé",
            suggestedAction = "Contrôler le faisceau et la sonde",
        ),
        DtcCode(
            code = "P1C5F",
            description = "Perte de puissance spécifique Jeep",
            severity = DtcSeverity.HIGH,
            probableCauses = "Problème de turbo ou fuite d'admission",
            suggestedAction = "Contrôler le turbo et l'admission",
        ),
    )

    fun describe(code: String): DtcCode = known.firstOrNull { it.code == code }
        ?: DtcCode(
            code = code,
            description = "Code constructeur ou description indisponible",
            severity = DtcSeverity.MEDIUM,
            probableCauses = "Diagnostic complémentaire requis",
            suggestedAction = "Consulter la documentation constructeur",
        )
}

