package com.axelhabeillon.jeepcockpit.core.model

import com.google.common.truth.Truth.assertThat
import org.junit.Test

class VehicleTelemetryTest {
    @Test
    fun `coolant alert has priority`() {
        val telemetry = VehicleTelemetry(
            rpm = 2_000,
            coolantCelsius = 105,
            oilPressureBar = 0.4,
            batteryVolts = 11.5,
        )
        assertThat(telemetry.criticalMessage).isEqualTo("Température moteur critique")
    }

    @Test
    fun `normal stopped vehicle does not flag oil pressure`() {
        val telemetry = VehicleTelemetry(
            rpm = 0,
            coolantCelsius = 90,
            oilPressureBar = 0.0,
            batteryVolts = 12.6,
        )
        assertThat(telemetry.criticalMessage).isNull()
    }
}

