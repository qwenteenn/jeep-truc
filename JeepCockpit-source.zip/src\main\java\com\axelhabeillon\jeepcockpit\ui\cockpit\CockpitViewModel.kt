package com.axelhabeillon.jeepcockpit.ui.cockpit

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.axelhabeillon.jeepcockpit.core.model.ConnectionState
import com.axelhabeillon.jeepcockpit.core.model.UnitSystem
import com.axelhabeillon.jeepcockpit.core.model.UserSettings
import com.axelhabeillon.jeepcockpit.core.model.VehicleTelemetry
import com.axelhabeillon.jeepcockpit.core.repository.SettingsRepository
import com.axelhabeillon.jeepcockpit.domain.ObserveVehicleUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class CockpitUiState(
    val telemetry: VehicleTelemetry = VehicleTelemetry(),
    val connectionState: ConnectionState = ConnectionState.Disconnected,
    val settings: UserSettings = UserSettings(),
)

@HiltViewModel
class CockpitViewModel @Inject constructor(
    observeVehicle: ObserveVehicleUseCase,
    settingsRepository: SettingsRepository,
) : ViewModel() {
    val uiState = combine(
        observeVehicle(),
        observeVehicle.connectionState(),
        settingsRepository.settings,
    ) { telemetry, connection, settings ->
        CockpitUiState(telemetry, connection, settings)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = CockpitUiState(),
    )

    init {
        viewModelScope.launch {
            settingsRepository.settings.distinctUntilChanged().collect {
                observeVehicle.start()
            }
        }
    }
}

fun VehicleTelemetry.displaySpeed(unitSystem: UnitSystem): Pair<Int, String> = when (unitSystem) {
    UnitSystem.METRIC -> speedKph to "km/h"
    UnitSystem.IMPERIAL -> (speedKph * 0.621371).toInt() to "mph"
}

fun VehicleTelemetry.displayDistance(unitSystem: UnitSystem): Pair<Double, String> = when (unitSystem) {
    UnitSystem.METRIC -> tripDistanceKm to "km"
    UnitSystem.IMPERIAL -> tripDistanceKm * 0.621371 to "mi"
}

fun VehicleTelemetry.displayOutsideTemperature(unitSystem: UnitSystem): Pair<Int, String> =
    when (unitSystem) {
        UnitSystem.METRIC -> outsideTemperatureCelsius to "°C"
        UnitSystem.IMPERIAL -> (outsideTemperatureCelsius * 9.0 / 5.0 + 32).toInt() to "°F"
    }

