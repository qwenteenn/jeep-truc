# Jeep Cockpit

Application Android native Kotlin/Jetpack Compose pour Jeep Renegade, réalisée à partir du cahier des charges du 12 août 2026.

## Fonctionnalités livrées

- Cockpit temps réel : vitesse, RPM, température moteur, carburant, pression d'huile, batterie, consommations, température extérieure, trajet, GPS et voyants.
- Mode démonstration activé par défaut pour parcourir l'application sans véhicule.
- Connexion Bluetooth Classic RFCOMM à un module ELM327/Veepeak déjà appairé.
- Lecture OBD-II des PID vitesse, RPM, température, carburant, pression d'huile, température extérieure et tension batterie.
- Scanner DTC : commande `03`, recherche, filtres par gravité, historique Room, export CSV et effacement confirmé via la commande `04`.
- Paramètres persistants : module Bluetooth, unités, fréquence de rafraîchissement et alertes.
- Architecture UI/domain/data, injection Hilt, stockage Room et DataStore.

## Démarrage

1. Ouvrir ce dossier dans Android Studio (JDK 17).
2. Lancer la configuration `app` sur Android 8.0 ou supérieur.
3. L'application démarre en **mode démonstration**.
4. Pour le véhicule : appairer le Veepeak dans Android, ouvrir **Réglages**, désactiver le mode démonstration, autoriser le Bluetooth, puis sélectionner le module.

## Sécurité et limites du premier livrable

- Aucune commande de commande moteur ou d'écriture ECU n'est implémentée.
- L'unique écriture OBD-II est l'effacement standard des défauts (`04`), derrière un dialogue de confirmation.
- Le Bluetooth réel doit être validé sur le modèle exact de Veepeak et sur la Jeep Renegade 2016 avant usage routier.
- Les consommations instantanée et moyenne sont simulées en mode démonstration ; l'OBD-II standard ne fournit pas toujours les PID nécessaires sur tous les calculateurs.
- Les données GPS réelles et les notifications système critiques sont préparées dans l'interface mais nécessitent une validation appareil/permissions complémentaire.

## Vérification en ligne de commande

```powershell
./gradlew.bat testDebugUnitTest assembleDebug
```

L'APK de développement est généré dans `app/build/outputs/apk/debug/`.

