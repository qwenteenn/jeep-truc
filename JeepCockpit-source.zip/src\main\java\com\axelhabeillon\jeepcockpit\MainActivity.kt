package com.axelhabeillon.jeepcockpit

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import com.axelhabeillon.jeepcockpit.ui.JeepCockpitApp
import com.axelhabeillon.jeepcockpit.ui.theme.JeepCockpitTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            JeepCockpitTheme {
                JeepCockpitApp()
            }
        }
    }
}

