package com.axelhabeillon.jeepcockpit.data.obd

import com.google.common.truth.Truth.assertThat
import org.junit.Test

class Elm327ParserTest {
    @Test
    fun `parses standard speed response`() {
        assertThat(Elm327Parser.speedKph("41 0D 3C\r>")) .isEqualTo(60)
    }

    @Test
    fun `parses standard rpm response`() {
        assertThat(Elm327Parser.rpm("41 0C 1A F8\r>")) .isEqualTo(1_726)
    }

    @Test
    fun `parses coolant fuel oil and voltage`() {
        assertThat(Elm327Parser.coolantCelsius("41 05 7B")).isEqualTo(83)
        assertThat(Elm327Parser.fuelPercent("41 2F 80")).isEqualTo(50)
        assertThat(Elm327Parser.oilPressureBar("41 0A 64")).isWithin(0.001).of(3.0)
        assertThat(Elm327Parser.voltage("ATRV\r14.2V\r>")) .isWithin(0.001).of(14.2)
    }

    @Test
    fun `decodes multiple DTC codes and ignores terminator`() {
        assertThat(Elm327Parser.dtcCodes("43 01 00 04 20 00 00\r>"))
            .containsExactly("P0100", "P0420")
            .inOrder()
    }
}

