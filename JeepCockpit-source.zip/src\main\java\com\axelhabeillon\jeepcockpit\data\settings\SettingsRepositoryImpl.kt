package com.axelhabeillon.jeepcockpit.data.settings

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.axelhabeillon.jeepcockpit.core.model.BluetoothDeviceInfo
import com.axelhabeillon.jeepcockpit.core.model.UnitSystem
import com.axelhabeillon.jeepcockpit.core.model.UserSettings
import com.axelhabeillon.jeepcockpit.core.repository.SettingsRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.settingsDataStore by preferencesDataStore(name = "jeep_settings")

@Singleton
class SettingsRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context,
) : SettingsRepository {
    private object Keys {
        val demoMode = booleanPreferencesKey("demo_mode")
        val deviceAddress = stringPreferencesKey("device_address")
        val deviceName = stringPreferencesKey("device_name")
        val unitSystem = stringPreferencesKey("unit_system")
        val refreshMillis = longPreferencesKey("refresh_millis")
        val notifications = booleanPreferencesKey("notifications")
    }

    override val settings: Flow<UserSettings> = context.settingsDataStore.data.map { preferences ->
        UserSettings(
            demoMode = preferences[Keys.demoMode] ?: true,
            selectedDeviceAddress = preferences[Keys.deviceAddress],
            selectedDeviceName = preferences[Keys.deviceName],
            unitSystem = preferences[Keys.unitSystem]
                ?.let { runCatching { UnitSystem.valueOf(it) }.getOrNull() }
                ?: UnitSystem.METRIC,
            refreshIntervalMillis = preferences[Keys.refreshMillis] ?: 500L,
            notificationsEnabled = preferences[Keys.notifications] ?: true,
        )
    }

    override suspend fun setDemoMode(enabled: Boolean) {
        context.settingsDataStore.edit { it[Keys.demoMode] = enabled }
    }

    override suspend fun setSelectedDevice(device: BluetoothDeviceInfo) {
        context.settingsDataStore.edit {
            it[Keys.deviceAddress] = device.address
            it[Keys.deviceName] = device.name
            it[Keys.demoMode] = false
        }
    }

    override suspend fun setUnitSystem(unitSystem: UnitSystem) {
        context.settingsDataStore.edit { it[Keys.unitSystem] = unitSystem.name }
    }

    override suspend fun setRefreshInterval(milliseconds: Long) {
        require(milliseconds in 100L..10_000L)
        context.settingsDataStore.edit { it[Keys.refreshMillis] = milliseconds }
    }

    override suspend fun setNotificationsEnabled(enabled: Boolean) {
        context.settingsDataStore.edit { it[Keys.notifications] = enabled }
    }

    @SuppressLint("MissingPermission")
    override fun bondedDevices(): Result<List<BluetoothDeviceInfo>> = runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            error("Autorisation Bluetooth requise")
        }
        val adapter = context.getSystemService(BluetoothManager::class.java)?.adapter
            ?: error("Bluetooth indisponible sur cet appareil")
        check(adapter.isEnabled) { "Activez le Bluetooth" }
        adapter.bondedDevices
            .map { BluetoothDeviceInfo(it.name ?: "Module OBD-II", it.address) }
            .sortedBy { it.name.lowercase() }
    }
}
