package com.axelhabeillon.jeepcockpit.ui.settings

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.axelhabeillon.jeepcockpit.core.model.BluetoothDeviceInfo
import com.axelhabeillon.jeepcockpit.core.model.UnitSystem
import com.axelhabeillon.jeepcockpit.ui.theme.JeepDarkGray
import com.axelhabeillon.jeepcockpit.ui.theme.JeepOrange
import com.axelhabeillon.jeepcockpit.ui.theme.JeepTextGray

@Composable
fun SettingsRoute(viewModel: SettingsViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    SettingsScreen(
        state = state,
        onDemoModeChange = viewModel::setDemoMode,
        onUnitSystemChange = viewModel::setUnitSystem,
        onRefreshIntervalChange = viewModel::setRefreshInterval,
        onNotificationsChange = viewModel::setNotifications,
        onLoadDevices = viewModel::loadBondedDevices,
        onSelectDevice = viewModel::selectDevice,
        onMessageConsumed = viewModel::consumeMessage,
    )
}

@Composable
fun SettingsScreen(
    state: SettingsUiState,
    onDemoModeChange: (Boolean) -> Unit,
    onUnitSystemChange: (UnitSystem) -> Unit,
    onRefreshIntervalChange: (Long) -> Unit,
    onNotificationsChange: (Boolean) -> Unit,
    onLoadDevices: () -> Unit,
    onSelectDevice: (BluetoothDeviceInfo) -> Unit,
    onMessageConsumed: () -> Unit,
) {
    val snackbar = remember { SnackbarHostState() }
    val bluetoothPermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
    } else {
        arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { result ->
        if (result.values.all { it }) onLoadDevices()
    }

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it)
            onMessageConsumed()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
    ) {
        SnackbarHost(snackbar)
        Spacer(Modifier.height(10.dp))
        Text("CONFIGURATION", color = JeepOrange, fontWeight = FontWeight.Bold)
        Text("Réglages", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(16.dp))

        SettingCard(
            icon = { Icon(Icons.Default.Bluetooth, contentDescription = null, tint = JeepOrange) },
            title = "Connexion OBD-II",
            subtitle = if (state.settings.demoMode) {
                "Les données sont simulées, sans action sur le véhicule."
            } else {
                state.settings.selectedDeviceName ?: "Sélectionnez un module Veepeak appairé."
            },
        ) {
            SettingToggleRow(
                label = "Mode démonstration",
                checked = state.settings.demoMode,
                onCheckedChange = onDemoModeChange,
            )
            if (!state.settings.demoMode) {
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = { permissionLauncher.launch(bluetoothPermissions) },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    if (state.isLoadingDevices) {
                        CircularProgressIndicator(modifier = Modifier.height(18.dp), strokeWidth = 2.dp)
                    } else {
                        Text("AFFICHER LES APPAREILS APPAIRÉS")
                    }
                }
                state.bondedDevices.forEach { device ->
                    DeviceRow(
                        device = device,
                        selected = device.address == state.settings.selectedDeviceAddress,
                        onClick = { onSelectDevice(device) },
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        SettingCard(
            icon = { Icon(Icons.Default.Straighten, contentDescription = null, tint = JeepOrange) },
            title = "Unités",
            subtitle = "Choisissez les unités affichées dans le cockpit.",
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                UnitSystem.entries.forEach { unit ->
                    FilterChip(
                        selected = state.settings.unitSystem == unit,
                        onClick = { onUnitSystemChange(unit) },
                        label = { Text(unit.label) },
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        SettingCard(
            icon = { Icon(Icons.Default.Speed, contentDescription = null, tint = JeepOrange) },
            title = "Rafraîchissement",
            subtitle = "Fréquence d'interrogation des paramètres du véhicule.",
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1_000L to "1 Hz", 500L to "2 Hz", 200L to "5 Hz", 100L to "10 Hz").forEach { option ->
                    FilterChip(
                        selected = state.settings.refreshIntervalMillis == option.first,
                        onClick = { onRefreshIntervalChange(option.first) },
                        label = { Text(option.second) },
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        SettingCard(
            icon = { Icon(Icons.Default.Notifications, contentDescription = null, tint = JeepOrange) },
            title = "Alertes",
            subtitle = "Avertir lorsqu'un code critique ou une valeur dangereuse apparaît.",
        ) {
            SettingToggleRow(
                label = "Notifications critiques",
                checked = state.settings.notificationsEnabled,
                onCheckedChange = onNotificationsChange,
            )
        }

        Spacer(Modifier.height(20.dp))
        Text(
            "Jeep Cockpit 1.0 - Les commandes OBD-II doivent être utilisées véhicule immobilisé lors d'un diagnostic.",
            color = JeepTextGray,
            style = MaterialTheme.typography.bodyMedium,
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun SettingCard(
    icon: @Composable () -> Unit,
    title: String,
    subtitle: String,
    content: @Composable () -> Unit,
) {
    Card(colors = CardDefaults.cardColors(containerColor = JeepDarkGray)) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                icon()
                Column(Modifier.padding(start = 10.dp)) {
                    Text(title, fontWeight = FontWeight.Bold)
                    Text(subtitle, color = JeepTextGray, style = MaterialTheme.typography.bodyMedium)
                }
            }
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
private fun SettingToggleRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun DeviceRow(device: BluetoothDeviceInfo, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Column {
            Text(device.name, fontWeight = FontWeight.Bold)
            Text(device.address, color = JeepTextGray, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
