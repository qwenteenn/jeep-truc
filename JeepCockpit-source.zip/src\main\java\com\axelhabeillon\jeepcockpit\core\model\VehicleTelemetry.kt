package com.axelhabeillon.jeepcockpit.core.model

data class VehicleTelemetry(
    val timestampMillis: Long = System.currentTimeMillis(),
    val speedKph: Int = 0,
    val rpm: Int = 0,
    val coolantCelsius: Int = 20,
    val fuelPercent: Int = 0,
    val oilPressureBar: Double = 0.0,
    val batteryVolts: Double = 12.6,
    val instantConsumptionLitresPer100Km: Double = 0.0,
    val averageConsumptionLitresPer100Km: Double = 0.0,
    val outsideTemperatureCelsius: Int = 20,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val gpsSpeedKph: Int? = null,
    val tripDistanceKm: Double = 0.0,
    val drivingSeconds: Long = 0,
    val indicators: Set<VehicleIndicator> = emptySet(),
) {
    val criticalMessage: String?
        get() = when {
            coolantCelsius > 100 -> "Température moteur critique"
            oilPressureBar < 1.0 && rpm > 500 -> "Pression d'huile trop basse"
            batteryVolts < 12.0 -> "Tension batterie faible"
            VehicleIndicator.MIL in indicators -> "Voyant moteur actif"
            else -> null
        }
}

enum class VehicleIndicator(val label: String) {
    MIL("Moteur"),
    OIL("Huile"),
    BATTERY("Batterie"),
    ABS("ABS"),
    AIRBAG("Airbag"),
}

sealed interface ConnectionState {
    data object Disconnected : ConnectionState
    data object Connecting : ConnectionState
    data class Connected(val deviceName: String, val demo: Boolean) : ConnectionState
    data class Error(val message: String) : ConnectionState
}

