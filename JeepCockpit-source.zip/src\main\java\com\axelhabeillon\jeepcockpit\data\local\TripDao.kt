package com.axelhabeillon.jeepcockpit.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TripDao {
    @Query("SELECT * FROM trips ORDER BY startedAtMillis DESC")
    fun observeAll(): Flow<List<TripEntity>>

    @Insert
    suspend fun insert(trip: TripEntity)
}

