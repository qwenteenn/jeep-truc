package com.axelhabeillon.jeepcockpit.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [DtcEntity::class, TripEntity::class],
    version = 1,
    exportSchema = true,
)
abstract class JeepDatabase : RoomDatabase() {
    abstract fun dtcDao(): DtcDao
    abstract fun tripDao(): TripDao
}

