package com.axelhabeillon.jeepcockpit.domain

import com.axelhabeillon.jeepcockpit.core.repository.VehicleRepository
import javax.inject.Inject

class ObserveVehicleUseCase @Inject constructor(
    private val repository: VehicleRepository,
) {
    operator fun invoke() = repository.telemetry
    fun connectionState() = repository.connectionState
    suspend fun start() = repository.start()
    suspend fun stop() = repository.stop()
}

