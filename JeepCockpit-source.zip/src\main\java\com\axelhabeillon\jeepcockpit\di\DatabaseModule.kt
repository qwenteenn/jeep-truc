package com.axelhabeillon.jeepcockpit.di

import android.content.Context
import androidx.room.Room
import com.axelhabeillon.jeepcockpit.data.local.DtcDao
import com.axelhabeillon.jeepcockpit.data.local.JeepDatabase
import com.axelhabeillon.jeepcockpit.data.local.TripDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): JeepDatabase =
        Room.databaseBuilder(context, JeepDatabase::class.java, "jeep-cockpit.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides
    fun provideDtcDao(database: JeepDatabase): DtcDao = database.dtcDao()

    @Provides
    fun provideTripDao(database: JeepDatabase): TripDao = database.tripDao()
}

